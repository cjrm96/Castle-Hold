'use strict';
/* Castle Siege build settings. The packaging script rewrites this file for each build:
   full web game, free demo for game websites, and the Steam desktop app. */
const BUILD={
  "version": "1.1.0",
  "edition": "demo",
  "ads": "crazygames",
  "platform": "web",
  "packs": [],
  "storeUrl": "",
  "packUrl": {
    "frontier": ""
  }
};
