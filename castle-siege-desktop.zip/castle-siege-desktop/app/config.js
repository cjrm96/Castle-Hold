'use strict';
/* Castle Siege build settings. The packaging script rewrites this file for each build:
   full web game, free demo for game websites, and the Steam desktop app. */
const BUILD={
  "version": "1.1.0",
  "edition": "full",
  "ads": "none",
  "platform": "steam",
  "packs": [
    "frontier"
  ],
  "storeUrl": "",
  "packUrl": {
    "frontier": ""
  }
};
